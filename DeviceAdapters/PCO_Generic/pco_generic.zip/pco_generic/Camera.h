#ifndef CAMERA_H
#define CAMERA_H

typedef unsigned char byte;     /* 8-bit  */
typedef unsigned short word;    /* 16-bit */
typedef unsigned long dword;    /* 32-bit */

#define NOERR  0
//#define NOTINIT -1
#define TIMEOUT -2

#define PCO_ERRT_H_CREATE_OBJECT
#include "PCO_err.h"
#include "PCO_errt.h"

extern void InitLib(unsigned char, char*, int, char*);
#define MMIJ 5

class CKamSensi;
class CKamPcCam;
class CKamSC2;
class CKamBase;

class CCamera
{
public:
  CKamSensi    *SensiCam;
  CKamPcCam    *PixelFly;
  CKamSC2      *SC2;
  CKamBase     *CamBase;
  // Variablendeklarationen
  int          iCamClass;  // 1: SensiCam, 2: PixelFly, 3: SC2
  char         szCamName[20];
  bool         bDemoMode;
  bool         bCameraLost;
  int          iCamTypeCurrentNumber;
  int          iCameraCnt;
  unsigned int uiLogfile;
  bool         bNumber;
 // Funktionsdeklarationen
  CCamera();
  ~CCamera();
  int PreInitSen(int numbersi, int iCamCnt, unsigned int uiLog);
  int PreInitPcCam(int numberpf, int iCamCnt, unsigned int uiLog);
  int PreInitSC2(int numbersc2, int iCamCnt, unsigned int uiLog);

  int Init(bool);
  int CloseCam();

// File related functions:

// Image buffer related functions:

  word * const GetPic12(WORD* wmean) const;
  byte * GetPic8();
  byte * GetPic8c();

  bool ReloadSize();
  int  WaitForImage();
  int GetBitsPerPixel();

// Convert functions:
  void Convert();
  void SetFlip(bool);
  void SetConvertBWCol(bool bBW, bool bCol);

// Camera related functions:
  int PreStartCam(unsigned int uiMode, int iFirstPic, int iStartPic, int iEndPic);// Aufruf zum Vorbereiten des live Preview
  int StartCam();
  int  StopCam();
  void ResetEvWait();
  int GetXRes() const;
  int GetYRes() const;

  int  GetCCDCol();
  int  GetCamType() const;
  int  GetMaximumROI(int *iRoiXMax, int *iRoiYMax);
  int setcoc(int mode, int trig, int roix1, int roix2, int roiy1, int roiy2, int hbin, int vbin, char* table, int gain, int offset, unsigned int flags);
  int getsettings(int* mode, int* trig, int* roix1, int* roix2, int* roiy1, int* roiy2, int* hbin, int* vbin, char* table, int *gain, int *offset, unsigned int* flags);
  int testcoc(int* mode, int* trig, int* roix1, int* roix2, int* roiy1, int* roiy2, int* hbin, int* vbin, char* table,int* size, int *gain, int *offset, unsigned int* flags);
  int getccdsize(int*, int*, int*);

// Dialog related functions:

// Recorder related functions:

// Administrative functions:
};
#endif